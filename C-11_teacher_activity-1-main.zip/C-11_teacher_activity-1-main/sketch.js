var marks = [30,40,45,35];


function setup() {
  createCanvas(400, 400);

}

function draw() {
  background(150);
}